docker build -t [tag] .

docker run -it -v ${pwd}:/[workspace] --name [name] [tag]

conda activate sfm

cd workspace

python sfm.py